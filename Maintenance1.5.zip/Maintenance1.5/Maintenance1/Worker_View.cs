﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Maintenance1
{
    public partial class Form4 : Form
    {
        DB con = new DB();
        private static ArrayList serialnumberl = new ArrayList();
        private static ArrayList CPUl = new ArrayList();
        private static ArrayList GPUl = new ArrayList();
        private static ArrayList probleml = new ArrayList();
        private static ArrayList storagel = new ArrayList();
        private static ArrayList raml = new ArrayList();
        private static ArrayList Receptionistl = new ArrayList();
        public Form4()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public void GetData()
        {

            con.Open();

            string query = "select * from item where manager IS NULL and status='im'";
            try
            {
                MySqlDataReader row;
                row = con.ExecuteReader(query);

                if (row.HasRows)
                {
                    while (row.Read())
                    {
                        serialnumberl.Add(row["Serial_number"].ToString());
                        CPUl.Add(row["CPU"].ToString());
                        GPUl.Add(row["GPU"].ToString());
                        raml.Add(row["RAM"].ToString());
                        storagel.Add(row["storage"].ToString());
                        probleml.Add(row["problem"].ToString());
                        
                        Receptionistl.Add(row["Receptionist"].ToString());
                    }
                }
                
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString());
            }

            con.Close();
            updateData();

        }
        private void updateData()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < serialnumberl.Count; i++)
            {
                DataGridViewRow newRow = new DataGridViewRow();

                newRow.CreateCells(dataGridView1);
                newRow.Cells[0].Value = serialnumberl[i];
                newRow.Cells[1].Value = CPUl[i];
                newRow.Cells[2].Value = GPUl[i];
                newRow.Cells[3].Value = storagel[i];
                newRow.Cells[4].Value = raml[i];
                newRow.Cells[5].Value = probleml[i];
                newRow.Cells[6].Value = Receptionistl[i];

                dataGridView1.Rows.Add(newRow);
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            serialnumberl.Clear();
            CPUl.Clear();
            GPUl.Clear();
            probleml.Clear();
            storagel.Clear();
            raml.Clear();
            Receptionistl.Clear();

            GetData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            String sql = "UPDATE item\r\nSET manager =" + textBox2.Text + "\r\n WHERE `Serial_number` = " + textbox1.Text + ";";
            con.ExecuteNonQuery(sql);
            MessageBox.Show("item reported");
            con.Close();
            Form4 f = new Form4();
            f.Show();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            String sql = "UPDATE item\r\nSET Status = 'f', solution = \"" + textBox3.Text + "\", Repair_Cost =" + textBox4.Text + "\r\n WHERE `Serial_number` = " + textbox1.Text + ";";
            con.ExecuteNonQuery(sql);
            MessageBox.Show("Maintenace finished");
            


            // Sender's email address and password
            string fromEmail = "taleb.13579.2023@gmail.com";
            string password = "pygjygdffaqdasop";
            string to="";

            // Recipient's email address

            string sql2 = "SELECT c.email  FROM customer c JOIN item i ON c.phone = i.owner where i.serial_number= " + textbox1.Text;
            MySqlDataReader red =con.ExecuteReader(sql2);
            while (red.Read()) {
                 to = (red["email"]).ToString();
            }
            // Create a new MailMessage object
            MailMessage mail = new MailMessage();

            // Set the sender, recipient, subject, and body of the message
            mail.From = new MailAddress(fromEmail);
            
            mail.To.Add(new MailAddress(to));
            mail.Subject = "Item Maintained";
            mail.Body = "Hello! \n your item with serial number + " + textbox1.Text + "is finished. Please pass by within 3 days \n Thanks";

            // Create a new SmtpClient object and configure it
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential(fromEmail, password);

            // Send the message
            smtp.Send(mail);
            con.Close();

            Form4 f = new Form4();
            f.Show();
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maintenance1
{
    public partial class Manager_Add_Staff : Form
    {
        public Manager_Add_Staff()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 f = new Form5();
            f.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox6.Text == textBox7.Text)
            {
                            
                try
                {
                    DB con = new DB();
                    con.Open();
                    string sql = "insert into staff(firstname,lastname,phone,email,username,password,role) values(\"" + textBox1.Text + "\",\"" + textBox2.Text + "\",\"" + textBox3.Text + "\",\"" + textBox4.Text + "\",\"" + textBox5.Text + "\",\"" + textBox6.Text + "\",\"" + comboBox1.Text +"\")" ;
                    con.ExecuteNonQuery(sql);
                    con.Close();
                    MessageBox.Show("Staff Added");
                    Form5 f5 = new Form5();
                    f5.Show();
                    this.Close();  
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            else
            {
                MessageBox.Show("passwords do not match");
            }
        }

        private void Manager_Add_Staff_Load(object sender, EventArgs e)
        {

        }
    }
}

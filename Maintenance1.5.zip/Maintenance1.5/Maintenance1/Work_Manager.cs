﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maintenance1
{
    public partial class Form5 : Form

    {
        DB con = new DB();
        private static ArrayList serialnumberl = new ArrayList();
        private static ArrayList CPUl = new ArrayList();
        private static ArrayList GPUl = new ArrayList();
        private static ArrayList probleml = new ArrayList();
        private static ArrayList solutionl = new ArrayList();
        private static ArrayList storagel = new ArrayList();
        private static ArrayList Statusl = new ArrayList();
        private static ArrayList raml = new ArrayList();
        private static ArrayList datersl = new ArrayList();
        private static ArrayList datertl = new ArrayList();
        private static ArrayList ownerl = new ArrayList();
        private static ArrayList workerl = new ArrayList();
        private static ArrayList Managerl = new ArrayList();
        private static ArrayList Receptionistl = new ArrayList();
        private static ArrayList Costl = new ArrayList();
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            serialnumberl.Clear();
            CPUl.Clear();
            GPUl.Clear();
            probleml.Clear();
            solutionl.Clear();
            storagel.Clear();
            Statusl.Clear();
            raml.Clear();
            datersl.Clear();
            datertl.Clear();
            ownerl.Clear();
            workerl.Clear();
            Managerl.Clear();
            Receptionistl.Clear();

            dataGridView1.Rows.Clear();
            GetData();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manager_Customers m = new Manager_Customers();
            m.Show();
            this.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void GetData()
        {

            con.Open();

            string query = "select * from item where manager ="+Globals.LoggedInUser+" and Status=\"im\"";
            try
            {
                MySqlDataReader row;
                row = con.ExecuteReader(query);

                if (row.HasRows)
                {
                    while (row.Read())
                    {
                        serialnumberl.Add(row["Serial_number"].ToString());
                        ownerl.Add(row["owner"].ToString());
                        datersl.Add(row["Date_Recived"].ToString());
                        CPUl.Add(row["CPU"].ToString());
                        GPUl.Add(row["GPU"].ToString());
                        raml.Add(row["RAM"].ToString());
                        Statusl.Add(row["Status"].ToString());
                        storagel.Add(row["storage"].ToString());
                        if (row.IsDBNull((row.GetOrdinal("Date_Returned"))))
                        {
                            datertl.Add("In Stock");
                        }
                        else
                        {
                            datertl.Add(row["Date_Returned"].ToString());
                        }
                        probleml.Add(row["problem"].ToString());
                        if (row.IsDBNull(row.GetOrdinal("solution")))
                        {
                            solutionl.Add("no Solution");
                        }
                        else
                        {
                            solutionl.Add(row["solution"].ToString());
                        }
                        if ((row.IsDBNull((row.GetOrdinal("Manager")))))
                        {
                            solutionl.Add("none");
                        }
                        else
                        {
                            Managerl.Add(row["Manager"].ToString());
                        }
                        workerl.Add(row["worker"].ToString());
                        Receptionistl.Add(row["Receptionist"].ToString());
                        if ((row.IsDBNull((row.GetOrdinal("Repair_Cost")))))
                        {
                            Costl.Add("none");
                        }
                        else
                        {
                            Costl.Add(row["Repair_Cost"].ToString());
                        }
                    }
                    
                }
                else
                {
                    MessageBox.Show("Fatal Error,Data not found, Please Contact IT");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString());
            }

            con.Close();
            updateData();

        }
        private void updateData()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < serialnumberl.Count; i++)
            {
                DataGridViewRow newRow = new DataGridViewRow();

                newRow.CreateCells(dataGridView1);
                newRow.Cells[0].Value = serialnumberl[i];
                newRow.Cells[1].Value = ownerl[i];
                newRow.Cells[2].Value =workerl[i];
                newRow.Cells[3].Value = Receptionistl[i];
                switch (Statusl[i]) {
                    case "im":
                        newRow.Cells[4].Value = "In Maintenace";
                        break;
                    case "f":
                        newRow.Cells[4].Value = "Fixed";
                        break;
                    case "nf":
                        newRow.Cells[4].Value = "Not Fixed";
                        break;
                }
                newRow.Cells[5].Value = datersl[i];
                newRow.Cells[6].Value = datertl[i];
                newRow.Cells[7].Value = CPUl[i];
                newRow.Cells[8].Value = GPUl[i];
                newRow.Cells[10].Value = storagel[i];
                newRow.Cells[9].Value = raml[i];
                newRow.Cells[11].Value = probleml[i];
                newRow.Cells[12].Value = solutionl[i];
                newRow.Cells[13].Value = Managerl[i];
                newRow.Cells[14].Value = Costl[i];

                dataGridView1.Rows.Add(newRow);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Manager_Add_Staff m = new Manager_Add_Staff();
            m.Show();
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maintenance1
{
    public partial class Add_item : Form
    {
        public Add_item()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DB con = new DB();
                con.Open();
                string sql ="INSERT INTO mms.item (Serial_number, CPU, GPU, RAM, Storage, date_recived, problem,Status,owner,Receptionist,worker) VALUES"+ 
                "("+textBox1.Text +",\""+textBox2.Text + "\",\"" + textBox3.Text + "\",\"" + textBox4.Text + "\",\"" + textBox5.Text + "\","+ "CURRENT_DATE, \""+ textBox6.Text + "\",\"im\",\"" + textBox8.Text +"\","+Globals.LoggedInUser+","+textBox9.Text +")";
                con.ExecuteNonQuery(sql);
                con.Close();
                MessageBox.Show("item added");

                button1.Visible = false;

                PrintDocument pd = new PrintDocument();
                pd.PrintPage += new PrintPageEventHandler(pd_PrintPage);

                pd.Print();

                Receptionist_View r = new Receptionist_View();
                r.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            

            


           
        }
        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Get the graphics object
            Graphics g = e.Graphics;

            // Create a bitmap to hold the contents of the form
            Bitmap bmp = new Bitmap(this.Width, this.Height, g);
            this.DrawToBitmap(bmp, new Rectangle(0, 0, this.Width, this.Height));

            // Draw the bitmap onto the printed page
            g.DrawImage(bmp, e.MarginBounds);
        }

        private void Add_item_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Receptionist_View r = new Receptionist_View();
            r.Show();
            this.Close();
        }
    }
}

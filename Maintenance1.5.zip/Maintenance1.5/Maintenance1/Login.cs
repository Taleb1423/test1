﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Maintenance1
{
    public partial class Login : Form
    {
        DB db = new DB();

        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
         
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       
        private string Hash(String password)
        {
            SHA256 sha256 = SHA256.Create();
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            byte[] hashBytes = sha256.ComputeHash(passwordBytes);
            string hashedPassword = Convert.ToBase64String(hashBytes);
            return hashedPassword;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pass.UseSystemPasswordChar = true;
            button1.Visible=false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            pass.UseSystemPasswordChar = true;
            button1.Visible = false;
            button2.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pass.UseSystemPasswordChar = false;
            button1.Visible = true;
            button2.Visible = false;
        }
        private void log()
        {
            string username = user.Text;
            string password = pass.Text;
            string query = "select staffid,password,role from staff where username = @user";
            db.Open();
            MySqlCommand command = new MySqlCommand(query, db.getCon());
            command.Parameters.AddWithValue("@user", username);
            MySqlDataReader rd = command.ExecuteReader();
            while (rd.Read())
            {
                if (!rd.HasRows)
                {
                    MessageBox.Show("Incorrect Username");
                    return;
                }
                else
                {
                    if (!(rd["password"].ToString() == password))
                    {
                        MessageBox.Show("Inccorect Password");
                        return;
                    }
                    else
                    {
                       Globals.LoggedInUser = rd["staffid"].ToString();
                        Globals.LoggedinRole = rd["role"].ToString();
                        switch (rd["role"].ToString())
                        {
                            case "manager":
                                Form5 form5 = new Form5();
                                form5.Show();
                                break;
                            case "Receptionist":
                                Receptionist_View res = new Receptionist_View();
                                res.Show();

                                break;
                            case "worker":
                                Form4 form4 = new Form4();
                                form4.Show();
                                break;
                            default:
                                MessageBox.Show("error");
                                break;
                        }
                    }


                }
                
            }
            db.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            log();
        }
    }
    
    }
    

       



﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maintenance1
{
    public partial class Manager_Customers : Form
    {
        public Manager_Customers()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        DB con = new DB();
        private static ArrayList Firstnamel = new ArrayList();
        private static ArrayList Lastnamel = new ArrayList();
        private static ArrayList phonel = new ArrayList();
        private static ArrayList emaill = new ArrayList();


        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }



        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_Customer f = new Add_Customer();
            f.Show();
            this.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string q = "";
            switch (comboBox1.Text)
            {
                case "First Name":
                    q = "select firstname,lastname,phone,email from customer where firstname =\"" + textBox1.Text + "\"";
                    break;
                case "Last Name":
                    q = "select firstname,lastname,phone,email from customer where lastname =\"" + textBox1.Text + "\"";
                    break;
                case "Email":
                    q = "select firstname,lastname,phone,email from customer where email =\"" + textBox1.Text + "\"";
                    break;
                case "Phone":
                    q = "select firstname,lastname,phone,email from customer where phone = \"" + textBox1.Text + "\"";
                    break;
            }
            Firstnamel.Clear();
            Lastnamel.Clear();
            phonel.Clear();
            emaill.Clear();

            dataGridView1.Rows.Clear();

            GetData(q);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }
        public void GetData(string query)
        {

            con.Open();


            try
            {
                MySqlDataReader row;
                row = con.ExecuteReader(query);

                if (row.HasRows)
                {
                    while (row.Read())
                    {


                        Firstnamel.Add(row["firstname"].ToString());
                        Lastnamel.Add(row["lastname"].ToString());
                        phonel.Add(row["phone"].ToString());
                        emaill.Add(row["email"].ToString());


                    }
                }
                else
                {
                    MessageBox.Show("Data not found");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString());
            }

            con.Close();
            updateData();

        }
        public void GetData()
        {

            con.Open();

            string query = "select firstname,lastname,phone,email from customer";
            try
            {
                MySqlDataReader row;
                row = con.ExecuteReader(query);

                if (row.HasRows)
                {
                    while (row.Read())
                    {


                        Firstnamel.Add(row["firstname"].ToString());
                        Lastnamel.Add(row["lastname"].ToString());
                        phonel.Add(row["phone"].ToString());
                        emaill.Add(row["email"].ToString());


                    }
                }
                else
                {
                    MessageBox.Show("Data not found");
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString());
            }

            con.Close();
            updateData();

        }
        private void updateData()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < Firstnamel.Count; i++)
            {
                DataGridViewRow newRow = new DataGridViewRow();

                newRow.CreateCells(dataGridView1);
                newRow.Cells[0].Value = Firstnamel[i];
                newRow.Cells[1].Value = Lastnamel[i];
                newRow.Cells[2].Value = phonel[i];
                newRow.Cells[3].Value = emaill[i];

                dataGridView1.Rows.Add(newRow);
            }
        }

        private void Receptionist_View_Load(object sender, EventArgs e)
        {
            Firstnamel.Clear();
            Lastnamel.Clear();
            phonel.Clear();
            emaill.Clear();
            dataGridView1.Rows.Clear();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            GetData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Firstnamel.Clear();
            Lastnamel.Clear();
            phonel.Clear();
            emaill.Clear();
            dataGridView1.Rows.Clear();
            GetData();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form5 f = new Form5();
            f.Show();
            this.Close();

        }




        private void Manager_Customers_Load(object sender, EventArgs e)
        {
            Firstnamel.Clear();
            Lastnamel.Clear();
            phonel.Clear();
            emaill.Clear();
            dataGridView1.Rows.Clear();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            GetData();
        }

        private void Search_Click(object sender, EventArgs e)
        {
            string q = "";
            switch (comboBox1.Text)
            {
                case "First Name":
                    q = "select firstname,lastname,phone,email from customer where firstname =\"" + textBox1.Text + "\"";
                    break;
                case "Last Name":
                    q = "select firstname,lastname,phone,email from customer where lastname =\"" + textBox1.Text + "\"";
                    break;
                case "Email":
                    q = "select firstname,lastname,phone,email from customer where email =\"" + textBox1.Text + "\"";
                    break;
                case "Phone":
                    q = "select firstname,lastname,phone,email from customer where phone = \"" + textBox1.Text + "\"";
                    break;
            }
            Firstnamel.Clear();
            Lastnamel.Clear();
            phonel.Clear();
            emaill.Clear();

            dataGridView1.Rows.Clear();

            GetData(q);
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Firstnamel.Clear();
            Lastnamel.Clear();
            phonel.Clear();
            emaill.Clear();

            dataGridView1.Rows.Clear();

            GetData();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form5 f = new Form5();
            f.Show();
            this.Close();
        }
    }
}


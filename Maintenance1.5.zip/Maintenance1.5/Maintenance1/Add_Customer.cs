﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maintenance1
{
    public partial class Add_Customer : Form
    {
        public Add_Customer()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DB con = new DB();
                con.Open();
                string sql = "insert into customer(firstname,lastname,phone,email) values(\"" + textBox1.Text + "\",\"" + textBox2.Text + "\",\"" + textBox3.Text + "\",\"" + textBox4.Text + "\")";
                con.ExecuteNonQuery(sql);
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            MessageBox.Show("Customer Registered");
            Receptionist_View r = new Receptionist_View();
            r.Show();
            this.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Receptionist_View r = new Receptionist_View();
                r.Show();
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Add_Customer_Load(object sender, EventArgs e)
        {

        }
    }
}
